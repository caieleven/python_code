实验1：temp.py
实验2：time_after_1s.py
实验3：reverse开头的5个文件
实验4：txt.py