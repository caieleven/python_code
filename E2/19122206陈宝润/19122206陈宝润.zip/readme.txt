analyze.py  用于第3题P和N的关系分析
cutable_word1.py和cutable_word2.py分别为第4题第一、二版代码
pi.py  为第1题优化后的代码
pi1.py 为第1题未优化的代码
random_birthday.py 为第3题代码