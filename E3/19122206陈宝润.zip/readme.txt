验证实验6：grid.py
验证实验8：Kangaroo.py

设计实验1：ack.py	func2.py
设计实验2：Time.py
设计实验3：mrc.py
设计实验4：order2.py